import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'form-component',
  templateUrl: './form-component.component.html',
  styleUrls: ['./form-component.component.css']
})
export class FormComponentComponent{
  submit(f){
 window.alert("submitted!")
};

courseCategory=[
{id:1, name:'Trial Version'},
{id:2,  name:'Purchased'},
{id:3,  name:'Free'},
];





}


/*  constructor() {
    const name: string;
    var address: Address;
  }

 ngOnInit(){
 this.address= {
 street= "abc st",
 city=" abc city"
 };
  this.name = "s";
}

}

interface Address {
     street : string,
     state:string
} */
